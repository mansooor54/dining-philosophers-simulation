/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 09:15:37 by malmarzo          #+#    #+#             */
/*   Updated: 2025/11/23 11:55:37 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <pthread.h>
# include <sys/time.h>
# include <semaphore.h>
# include <signal.h>
# include <sys/wait.h>
# include <fcntl.h>
# include <sys/stat.h>

# define RED		"\033[1;31m"
# define GREEN		"\033[1;32m"
# define YELLOW		"\033[1;33m"
# define BLUE		"\033[1;34m"
# define PURPLE		"\033[1;35m"
# define WHITE		"\033[1;37m"
# define RESET		"\033[0m"

# define MAX_PHILOS 250

typedef struct s_data	t_data;

typedef struct s_philo
{
	int				id;
	int				eat_count;
	long long		last_meal_time;
	pid_t			pid;
	t_data			*data;
}	t_philo;

struct s_data
{
	int				num_philos;
	long long		time_to_die;
	long long		time_to_eat;
	long long		time_to_sleep;
	int				must_eat_count;

	long long		start_time;
	t_philo			*philos;

	sem_t			*sem_forks;
	sem_t			*sem_write;
	sem_t			*sem_meal;
	sem_t			*sem_death;
};

/* main / args */
int			check_args(int argc, char **argv);

/* init */
int			init_data(t_data *data, int argc, char **argv);

/* semaphore - bonus specific */
int			init_semaphores(t_data *data);
void		cleanup_semaphores(t_data *data);

/* process - bonus specific */
int			start_simulation(t_data *data);
void		kill_all_philos(t_data *data, int count);
void		wait_for_children(t_data *data);

/* time utils */
long long	get_time(void);
void		ft_usleep(long long time_ms_to_sleep);

/* routines */
void		philo_process(t_data *data, int id);

/* monitor */
void		*monitor_thread(void *arg);

/* printing */
void		print_status(t_philo *philo, const char *msg);

/* utils */
int			ft_atoi(const char *str);
void		cleanup(t_data *data);
void		exit_error(char *msg);

#endif
