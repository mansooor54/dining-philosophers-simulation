# philo_bonus Code Organization

## New File Structure

The bonus code has been reorganized to separate bonus-specific functionality into dedicated files:

### Core Files (Shared Concepts)
- **args.c** - Command-line argument parsing and validation
- **init.c** - Data structure initialization
- **utils.c** - Utility functions (ft_atoi, cleanup wrapper, exit_error)
- **print.c** - Status printing with color coding
- **time_utils.c** - Time-related utilities
- **philo_routine.c** - Philosopher eating/sleeping routine
- **monitor.c** - Death monitoring (per-process)

### Bonus-Specific Files (NEW)
- **semaphore.c** - Semaphore management
  - `init_semaphores()` - Opens named semaphores
  - `cleanup_semaphores()` - Closes and unlinks semaphores
  - Uses /philo_forks, /philo_write, /philo_meal, /philo_death

- **process.c** - Process management
  - `start_simulation()` - Forks philosopher processes
  - `kill_all_philos()` - Terminates processes
  - `wait_for_children()` - Waits for child processes
  - Handles fork() failures with proper cleanup

- **main.c** - Entry point (simplified)
  - Only contains main() function
  - Coordinates initialization and simulation

---

## Function Distribution

### semaphore.c (Bonus IPC)
```c
int   init_semaphores(t_data *data);
void  cleanup_semaphores(t_data *data);
```

### process.c (Bonus Concurrency)
```c
int   start_simulation(t_data *data);
void  kill_all_philos(t_data *data, int count);
void  wait_for_children(t_data *data);
```

### main.c (Entry Point)
```c
int   main(int argc, char **argv);
```

### init.c (Data Setup)
```c
int   init_data(t_data *data, int argc, char **argv);
```

### utils.c (Helpers)
```c
int   ft_atoi(const char *str);
void  cleanup(t_data *data);
void  exit_error(char *msg);
```

---

## Key Benefits of This Organization

1. **Clear Separation**: Bonus-specific code (semaphores, processes) isolated
2. **Modularity**: Each file has a single, clear responsibility
3. **Maintainability**: Easier to locate and modify specific functionality
4. **Reusability**: Common code (args, utils, time) unchanged
5. **Documentation**: File names clearly indicate their purpose

---

## Comparison with philo/

| File | philo (Threads) | philo_bonus (Processes) |
|------|-----------------|-------------------------|
| **Synchronization** | Uses pthread mutexes | Uses POSIX semaphores |
| **Concurrency** | pthread_create/join | fork/waitpid/kill |
| **Special Files** | None | `semaphore.c`, `process.c` |
| **main.c** | Complex thread management | Simple process launch |
| **Monitoring** | Central monitor thread | Distributed (per-process) |

---

## File Sizes (Approx)

- semaphore.c: ~60 lines - Semaphore lifecycle management
- process.c: ~80 lines - Process creation and management  
- main.c: ~35 lines - Simplified entry point
- init.c: ~50 lines - Clean data initialization

**Total**: Well-organized, modular codebase with clear responsibilities

