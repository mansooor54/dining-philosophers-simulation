/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_routine.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 09:15:37 by malmarzo          #+#    #+#             */
/*   Updated: 2025/11/23 11:55:37 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

static void	routine_eat(t_philo *philo)
{
	sem_wait(philo->data->sem_forks);
	print_status(philo, "has taken a fork");
	sem_wait(philo->data->sem_forks);
	print_status(philo, "has taken a fork");
	sem_wait(philo->data->sem_meal);
	print_status(philo, "is eating");
	philo->last_meal_time = get_time();
	philo->eat_count++;
	sem_post(philo->data->sem_meal);
	ft_usleep(philo->data->time_to_eat);
	sem_post(philo->data->sem_forks);
	sem_post(philo->data->sem_forks);
}

static void	start_philo_monitor(t_philo *philo)
{
	pthread_t	tid;

	philo->last_meal_time = get_time();
	pthread_create(&tid, NULL, monitor_thread, philo);
	pthread_detach(tid);
}

void	philo_process(t_data *data, int i)
{
	t_philo	*philo;

	philo = &data->philos[i];
	start_philo_monitor(philo);
	if (philo->id % 2 == 0)
		usleep(1000);
	while (1)
	{
		if (data->num_philos == 1)
		{
			sem_wait(data->sem_forks);
			print_status(philo, "has taken a fork");
			ft_usleep(data->time_to_die * 2);
			sem_post(data->sem_forks);
			exit(1);
		}
		routine_eat(philo);
		if (data->must_eat_count != -1
			&& philo->eat_count >= data->must_eat_count)
			exit(0);
		print_status(philo, "is sleeping");
		ft_usleep(data->time_to_sleep);
		print_status(philo, "is thinking");
	}
}
