/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 09:15:37 by malmarzo          #+#    #+#             */
/*   Updated: 2025/11/23 11:55:37 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

// void	print_status(t_philo *philo, const char *msg)
// {
// 	long long	timestamp;

// 	pthread_mutex_lock(&philo->data->write_lock);
// 	if (!is_dead(philo->data))
// 	{
// 		timestamp = get_time() - philo->data->start_time;
// 		printf("%lld %d %s\n", timestamp, philo->id, msg);
// 	}
// 	pthread_mutex_unlock(&philo->data->write_lock);
// }

void	print_status(t_philo *philo, const char *msg)
{
	long long	timestamp;
	const char	*color;

	sem_wait(philo->data->sem_write);
	timestamp = get_time() - philo->data->start_time;
	if (msg[0] == 'h')
		color = GREEN;
	else if (msg[0] == 'i' && msg[3] == 'e')
		color = PURPLE;
	else if (msg[0] == 'i' && msg[3] == 's')
		color = YELLOW;
	else if (msg[0] == 'i' && msg[3] == 't')
		color = BLUE;
	else
		color = RED;
	printf("%s%lld %d %s%s\n", color, timestamp, philo->id, msg, RESET);
	sem_post(philo->data->sem_write);
}
