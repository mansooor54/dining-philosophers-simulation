/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/11 20:00:00 by malmarzo          #+#    #+#             */
/*   Updated: 2025/12/11 20:00:00 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

void	kill_all_philos(t_data *data, int count)
{
	int	i;

	i = 0;
	while (i < count)
	{
		if (data->philos[i].pid > 0)
			kill(data->philos[i].pid, SIGKILL);
		i++;
	}
}

void	wait_for_children(t_data *data)
{
	pid_t	pid;
	int		status;
	int		finished_count;

	finished_count = 0;
	while (1)
	{
		pid = waitpid(-1, &status, 0);
		if (pid < 0)
			break ;
		if (WIFEXITED(status))
		{
			if (WEXITSTATUS(status) != 0)
				return (kill_all_philos(data, data->num_philos));
			finished_count++;
			if (finished_count == data->num_philos)
				return ;
		}
		else if (WIFSIGNALED(status))
			return (kill_all_philos(data, data->num_philos));
	}
}

int	start_simulation(t_data *data)
{
	int		i;
	pid_t	pid;

	data->start_time = get_time();
	i = 0;
	while (i < data->num_philos)
	{
		pid = fork();
		if (pid < 0)
		{
			kill_all_philos(data, i);
			while (--i >= 0)
				waitpid(data->philos[i].pid, NULL, 0);
			return (perror("fork"), 1);
		}
		if (pid == 0)
		{
			philo_process(data, i);
			exit(0);
		}
		data->philos[i].pid = pid;
		i++;
	}
	wait_for_children(data);
	return (0);
}
