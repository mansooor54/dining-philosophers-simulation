/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 09:15:37 by malmarzo          #+#    #+#             */
/*   Updated: 2025/11/23 11:55:37 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

int	main(int argc, char **argv)
{
	t_data	data;

	if (argc < 5 || argc > 6)
	{
		printf("Usage: ./philo_bonus <number_of_philosophers> <time_to_die> ");
		printf("<time_to_eat> <time_to_sleep> [must_eat]\n");
		return (1);
	}
	if (check_args(argc, argv) || init_data(&data, argc, argv))
		return (1);
	if (init_semaphores(&data))
		return (free(data.philos), 1);
	if (data.must_eat_count == 0)
		return (cleanup(&data), 0);
	start_simulation(&data);
	cleanup(&data);
	return (0);
}
