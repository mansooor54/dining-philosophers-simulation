/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitor.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 09:15:37 by malmarzo          #+#    #+#             */
/*   Updated: 2025/11/23 11:55:37 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

static int	check_death(t_philo *philo)
{
	long long	time;

	sem_wait(philo->data->sem_meal);
	if (get_time() - philo->last_meal_time > philo->data->time_to_die)
	{
		sem_post(philo->data->sem_meal);
		sem_wait(philo->data->sem_write);
		time = get_time() - philo->data->start_time;
		printf("%s%lld %d died%s\n", RED, time, philo->id, RESET);
		return (1);
	}
	sem_post(philo->data->sem_meal);
	return (0);
}

void	*monitor_thread(void *arg)
{
	t_philo	*philo;

	philo = (t_philo *)arg;
	while (1)
	{
		if (check_death(philo))
			exit(1);
		usleep(1000);
		if (philo->data->must_eat_count != -1)
		{
			sem_wait(philo->data->sem_meal);
			if (philo->eat_count >= philo->data->must_eat_count)
			{
				sem_post(philo->data->sem_meal);
			}
			else
				sem_post(philo->data->sem_meal);
		}
	}
	return (NULL);
}
