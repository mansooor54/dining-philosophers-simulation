/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   semaphore.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malmarzo <malmarzo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/11 20:00:00 by malmarzo          #+#    #+#             */
/*   Updated: 2025/12/11 20:00:00 by malmarzo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

static void	cleanup_sems(t_data *data, int level)
{
	if (level >= 1)
		sem_close(data->sem_forks);
	if (level >= 2)
		sem_close(data->sem_write);
	if (level >= 3)
		sem_close(data->sem_meal);
	if (level >= 4)
		sem_close(data->sem_death);
	sem_unlink("/philo_forks");
	sem_unlink("/philo_write");
	sem_unlink("/philo_meal");
	sem_unlink("/philo_death");
}

int	init_semaphores(t_data *data)
{
	sem_unlink("/philo_forks");
	sem_unlink("/philo_write");
	sem_unlink("/philo_meal");
	sem_unlink("/philo_death");
	data->sem_forks = sem_open("/philo_forks", O_CREAT, 0644, data->num_philos);
	if (data->sem_forks == SEM_FAILED)
		return (1);
	data->sem_write = sem_open("/philo_write", O_CREAT, 0644, 1);
	if (data->sem_write == SEM_FAILED)
		return (cleanup_sems(data, 1), 1);
	data->sem_meal = sem_open("/philo_meal", O_CREAT, 0644, 1);
	if (data->sem_meal == SEM_FAILED)
		return (cleanup_sems(data, 2), 1);
	data->sem_death = sem_open("/philo_death", O_CREAT, 0644, 0);
	if (data->sem_death == SEM_FAILED)
		return (cleanup_sems(data, 3), 1);
	return (0);
}

void	cleanup_semaphores(t_data *data)
{
	sem_close(data->sem_forks);
	sem_close(data->sem_write);
	sem_close(data->sem_meal);
	sem_close(data->sem_death);
	sem_unlink("/philo_forks");
	sem_unlink("/philo_write");
	sem_unlink("/philo_meal");
	sem_unlink("/philo_death");
}
