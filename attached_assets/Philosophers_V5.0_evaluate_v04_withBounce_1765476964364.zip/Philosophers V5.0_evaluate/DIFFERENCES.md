# Differences Between philo and philo_bonus

## Architecture Overview

### philo (Mandatory - Threads & Mutexes)
- Uses **pthread** threads
- Uses **pthread_mutex** for synchronization
- All philosophers share the same process space
- One monitor thread per simulation

### philo_bonus (Bonus - Processes & Semaphores)
- Uses **fork()** processes
- Uses **semaphores** for synchronization
- Each philosopher is a separate process
- One monitor thread per philosopher process

---

## File-by-File Differences

### 1. **Data Structures** (philo.h)

#### philo (mutexes):
```c
typedef struct s_philo {
    pthread_t       thread;
    pthread_mutex_t *left_fork;
    pthread_mutex_t *right_fork;
} t_philo;

typedef struct s_data {
    pthread_mutex_t *forks;
    pthread_mutex_t write_lock;
    pthread_mutex_t meal_lock;
    pthread_mutex_t dead_lock;
} t_data;
```

#### philo_bonus (semaphores):
```c
typedef struct s_philo {
    pid_t           pid;           // Process ID instead of thread
} t_philo;

typedef struct s_data {
    sem_t          *sem_forks;     // Semaphore instead of mutex array
    sem_t          *sem_write;
    sem_t          *sem_meal;
    sem_t          *sem_death;
} t_data;
```

---

### 2. **Initialization** (init.c)

#### philo - mutex initialization:
- `pthread_mutex_init()` for each fork
- Direct mutex operations
- Cleanup with `pthread_mutex_destroy()`

#### philo_bonus - semaphore initialization:
- `sem_open()` with named semaphores
- `/philo_forks`, `/philo_write`, `/philo_meal`, `/philo_death`
- Cleanup with `sem_close()` and `sem_unlink()`
- Semaphore count = num_philos for forks

---

### 3. **Main Loop** (main.c)

#### philo - Thread management:
```c
pthread_create(&philos[i].thread, NULL, philo_routine, &philos[i]);
pthread_join(philos[i].thread, NULL);
```
- Creates philosopher threads
- One monitor thread
- Joins all threads at end

#### philo_bonus - Process management:
```c
pid = fork();
if (pid == 0)
    philo_process(data, i);
data->philos[i].pid = pid;
waitpid(-1, &status, 0);
```
- Forks child processes
- Each child runs philosopher independently
- Parent waits for children with `waitpid()`
- Kills all children on death/completion

---

### 4. **Synchronization** (philo_routine.c)

#### philo - Mutex locking:
```c
pthread_mutex_lock(philo->left_fork);
pthread_mutex_lock(philo->right_fork);
// eat
pthread_mutex_unlock(philo->right_fork);
pthread_mutex_unlock(philo->left_fork);
```

#### philo_bonus - Semaphore waiting:
```c
sem_wait(philo->data->sem_forks);  // Take fork 1
sem_wait(philo->data->sem_forks);  // Take fork 2
// eat
sem_post(philo->data->sem_forks);  // Release fork 1
sem_post(philo->data->sem_forks);  // Release fork 2
```

---

### 5. **Monitor** (monitor.c)

#### philo - One monitor thread:
- Runs in main process
- Checks all philosophers in loop
- Sets shared `dead_flag`

#### philo_bonus - Monitor per philosopher:
- Each process creates its own monitor thread
- Monitors only itself
- Calls `exit(1)` on death
- Parent detects via `waitpid()` exit status

---

### 6. **Time Utilities** (time_utils.c)

#### philo:
```c
void ft_usleep(long long time_ms, t_data *data);
void wait_for_start(t_data *data);
```
- Checks `is_dead()` flag during sleep
- Waits for synchronized start

#### philo_bonus:
```c
void ft_usleep(long long time_ms);  // No data parameter
```
- No shared dead flag check
- Simpler implementation
- No synchronized start needed

---

### 7. **Print** (print.c)

#### philo:
```c
pthread_mutex_lock(&philo->data->write_lock);
if (!is_dead(philo->data))
    printf(...);
pthread_mutex_unlock(&philo->data->write_lock);
```

#### philo_bonus:
```c
sem_wait(philo->data->sem_write);
printf(...);  // No dead check needed
sem_post(philo->data->sem_write);
```

---

## Key Conceptual Differences

| Aspect | philo (Threads) | philo_bonus (Processes) |
|--------|----------------|-------------------------|
| **Concurrency Model** | Shared memory threads | Isolated processes |
| **Synchronization** | Mutexes | Semaphores |
| **Fork Representation** | Mutex array | Counting semaphore |
| **Death Detection** | Shared flag | Process exit status |
| **Monitor Strategy** | Central monitor | Distributed monitors |
| **Cleanup** | Join threads | Kill processes |
| **Communication** | Shared memory | IPC (semaphores) |
| **Resource Sharing** | Everything shared | Only semaphores shared |

---

## Bonus-Specific Code Elements

### Unique to philo_bonus:
1. **Process management**: `fork()`, `waitpid()`, `kill()`
2. **Named semaphores**: `/philo_*` names
3. **Exit-based signaling**: `exit(0)` for success, `exit(1)` for death
4. **Per-process monitor**: Each philosopher monitors itself
5. **Signal handling**: SIGKILL to terminate processes
6. **No shared state**: Each process has its own copy of data

### Unique to philo (mandatory):
1. **Thread management**: `pthread_create()`, `pthread_join()`
2. **Mutex arrays**: One mutex per fork
3. **Shared memory**: All threads see same variables
4. **Central monitor**: One thread checks all philosophers
5. **Dead flag**: Shared `int dead_flag` variable
6. **Synchronized start**: `start_time` coordination

---

## What Can Be Shared

Files with **minimal differences** (mostly just sync primitives):
- `args.c` - Nearly identical
- `utils.c` - Identical
- Color definitions in headers - Identical

Files with **significant differences**:
- `main.c` - Thread vs process creation
- `init.c` - Mutex vs semaphore setup
- `philo_routine.c` - Lock vs semaphore operations
- `monitor.c` - Central vs distributed monitoring
- `time_utils.c` - With/without dead flag checks
